/*
Toolbox Aid
David Quesenberry
03/25/2026
VectorMapRenderer3D.js
*/
export class VectorMapRenderer3D {
  project(point, view) {
    const angle = Math.PI / 6;
    const isoX = (point.x - point.z) * Math.cos(angle);
    const isoY = point.y + (point.x + point.z) * Math.sin(angle) * 0.5;
    return { x: isoX * view.zoom + view.offsetX, y: isoY * view.zoom + view.offsetY };
  }

  render(ctx, state) {
    const { canvas, documentData, selectionModel, view, hover, collisionVector, collisionHit } = state;
    ctx.clearRect(0, 0, canvas.width, canvas.height);
    ctx.fillStyle = documentData.background || "#000000";
    ctx.fillRect(0, 0, canvas.width, canvas.height);
    this.drawGrid(ctx, canvas, view);
    this.drawAxes(ctx, view);

    for (const object of documentData.objects) {
      this.drawObject(ctx, object, selectionModel.isSelectedObject(object.id), view);
    }

    const selection = selectionModel.getSelection({ getObjectById: (objectId) => documentData.objects.find((item) => item.id === objectId) });
    if (selection.object) {
      this.drawCenter(ctx, selection.object.center, view);
    }
    if (hover) {
      const projected = this.project(hover, view);
      ctx.save();
      ctx.strokeStyle = "#80e4a3";
      ctx.beginPath();
      ctx.arc(projected.x, projected.y, 6, 0, Math.PI * 2);
      ctx.stroke();
      ctx.restore();
    }
    if (collisionVector?.start && collisionVector?.end) {
      this.drawCollisionVector(ctx, collisionVector, collisionHit, view);
    }
  }

  drawGrid(ctx, canvas, view) {
    const step = Math.max(20, 40 * view.zoom);
    const offsetX = ((view.offsetX % step) + step) % step;
    const offsetY = ((view.offsetY % step) + step) % step;
    ctx.save();
    ctx.strokeStyle = "#162038";
    ctx.lineWidth = 1;
    for (let x = offsetX; x < canvas.width; x += step) {
      ctx.beginPath(); ctx.moveTo(x, 0); ctx.lineTo(x, canvas.height); ctx.stroke();
    }
    for (let y = offsetY; y < canvas.height; y += step) {
      ctx.beginPath(); ctx.moveTo(0, y); ctx.lineTo(canvas.width, y); ctx.stroke();
    }
    ctx.restore();
  }

  drawAxes(ctx, view) {
    const origin = this.project({ x: 0, y: 0, z: 0 }, view);
    const xAxis = this.project({ x: 120, y: 0, z: 0 }, view);
    const yAxis = this.project({ x: 0, y: 120, z: 0 }, view);
    const zAxis = this.project({ x: 0, y: 0, z: 120 }, view);
    ctx.save();
    ctx.lineWidth = 2;
    ctx.strokeStyle = "#7bc0ff"; ctx.beginPath(); ctx.moveTo(origin.x, origin.y); ctx.lineTo(xAxis.x, xAxis.y); ctx.stroke();
    ctx.strokeStyle = "#80e4a3"; ctx.beginPath(); ctx.moveTo(origin.x, origin.y); ctx.lineTo(yAxis.x, yAxis.y); ctx.stroke();
    ctx.strokeStyle = "#ffb36b"; ctx.beginPath(); ctx.moveTo(origin.x, origin.y); ctx.lineTo(zAxis.x, zAxis.y); ctx.stroke();
    ctx.restore();
  }

  drawObject(ctx, object, isSelected, view) {
    const points = object.points.map((point) => this.project(point, view));
    if (!points.length) {
      return;
    }
    ctx.save();
    ctx.lineWidth = Math.max(1, (object.style.lineWidth || 2) * view.zoom * 0.4);
    if (object.style.colorMode === "point" && points.length > 1) {
      for (let index = 0; index < points.length - 1; index += 1) {
        const gradient = ctx.createLinearGradient(points[index].x, points[index].y, points[index + 1].x, points[index + 1].y);
        gradient.addColorStop(0, object.points[index].color || object.style.stroke || "#ffffff");
        gradient.addColorStop(1, object.points[index + 1].color || object.style.stroke || "#ffffff");
        ctx.strokeStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(points[index].x, points[index].y);
        ctx.lineTo(points[index + 1].x, points[index + 1].y);
        ctx.stroke();
      }
      if (object.closed && points.length > 2) {
        const last = points[points.length - 1];
        const first = points[0];
        const gradient = ctx.createLinearGradient(last.x, last.y, first.x, first.y);
        gradient.addColorStop(0, object.points[object.points.length - 1].color || object.style.stroke || "#ffffff");
        gradient.addColorStop(1, object.points[0].color || object.style.stroke || "#ffffff");
        ctx.strokeStyle = gradient;
        ctx.beginPath();
        ctx.moveTo(last.x, last.y);
        ctx.lineTo(first.x, first.y);
        ctx.stroke();
      }
    } else {
      ctx.strokeStyle = object.style.stroke || "#ffffff";
      ctx.beginPath();
      ctx.moveTo(points[0].x, points[0].y);
      for (let index = 1; index < points.length; index += 1) {
        ctx.lineTo(points[index].x, points[index].y);
      }
      if (object.closed && points.length > 2) {
        ctx.closePath();
      }
      ctx.stroke();
    }

    for (let index = 0; index < points.length; index += 1) {
      const point = points[index];
      ctx.beginPath();
      ctx.fillStyle = object.points[index].color || "#ffd86b";
      ctx.arc(point.x, point.y, isSelected ? 5 : 4, 0, Math.PI * 2);
      ctx.fill();
      ctx.strokeStyle = "#09101d";
      ctx.stroke();
    }

    if (isSelected) {
      ctx.setLineDash([6, 6]);
      ctx.strokeStyle = "#6bb8ff";
      const xs = points.map((point) => point.x);
      const ys = points.map((point) => point.y);
      ctx.strokeRect(Math.min(...xs) - 8, Math.min(...ys) - 8, Math.max(...xs) - Math.min(...xs) + 16, Math.max(...ys) - Math.min(...ys) + 16);
      ctx.setLineDash([]);
    }
    ctx.restore();
  }

  drawCenter(ctx, center, view) {
    const point = this.project(center, view);
    const size = Math.max(8, Math.min(14, 10 * Math.sqrt(view.zoom)));
    ctx.save();
    ctx.strokeStyle = "#ff7ef4";
    ctx.lineWidth = 2;
    ctx.beginPath();
    ctx.moveTo(point.x - size, point.y); ctx.lineTo(point.x + size, point.y);
    ctx.moveTo(point.x, point.y - size); ctx.lineTo(point.x, point.y + size);
    ctx.stroke();
    ctx.restore();
  }

  drawCollisionVector(ctx, vector, hit, view) {
    const start = this.project(vector.start, view);
    const end = this.project(vector.end, view);
    ctx.save();
    ctx.strokeStyle = "#ffb36b";
    ctx.lineWidth = 2;
    ctx.setLineDash([10, 6]);
    ctx.beginPath(); ctx.moveTo(start.x, start.y); ctx.lineTo(end.x, end.y); ctx.stroke();
    ctx.setLineDash([]);
    for (const point of [start, end]) {
      ctx.beginPath(); ctx.fillStyle = "#ffb36b"; ctx.arc(point.x, point.y, 4, 0, Math.PI * 2); ctx.fill();
    }
    if (hit?.point) {
      const hitPoint = this.project(hit.point, view);
      ctx.beginPath(); ctx.fillStyle = "#ff7878"; ctx.arc(hitPoint.x, hitPoint.y, 6, 0, Math.PI * 2); ctx.fill();
    }
    ctx.restore();
  }
}
