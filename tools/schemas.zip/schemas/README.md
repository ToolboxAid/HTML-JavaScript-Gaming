# Tool and Workspace Schemas

All JSON schema contracts for tools, samples, palettes, and workspace manifests belong here.

Root-level schema files should not be added.

## Layout

```text
tools/schemas/
  workspace.manifest.schema.json
  palette.schema.json
  samples/
    sample.tool-payload.schema.json
  tools/
    <tool>.schema.json
```
