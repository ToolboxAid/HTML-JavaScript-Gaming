# PR 10.6 - Unified Tool System Contract Update

## Purpose

Define the shared tool-system contract before continuing tool-by-tool UAT.

This PR corrects the launch-mode model:

- Samples launch tools in standalone mode only.
- Games launch through `games/index.html` in-place with `Open in Workspace`.
- Workspace Manager is introduced through games, not sample learning flows.
- Tools with multi-event editing must wire the existing shared edit-history class for cut, copy, paste, undo, and redo.

## Scope

Docs-first contract only. Codex must not implement broad UI rewrites in this PR.

## Required Contract Updates

### 1. Launch Mode Contract

#### Samples

Samples are learning-first.

Required behavior:

- Sample tiles launch tools in standalone mode.
- Sample launches must not route through Workspace Manager.
- Sample tool UI must clearly show `Standalone Tool`.
- Sample tool launch must load manifest-declared sample data directly into the tool.
- Sample tools must not show workspace-only actions unless disabled with explanation.

Acceptance:

- `samples/index.html` launches standalone tools.
- No sample launch depends on workspace state.
- Sample users can learn each tool before entering Workspace.

#### Games

Games are workspace-first.

Required behavior:

- `games/index.html` opens games in-place.
- Game tiles expose `Open in Workspace`.
- Workspace launch receives game manifest data.
- Workspace owns game-level state, tool routing, and workspace save/export context.

Acceptance:

- `games/index.html` supports in-place workspace launch.
- Workspace launch is game-only.
- Workspace-specific buttons appear only in game/workspace mode.

### 2. Shared Tool Shell Contract

Every tool must follow the same UX shell shape:

- Shared header
- Context-aware toolbar
- Left navigation/data panel
- Main work area/canvas
- Right properties/state panel
- Footer/status area when useful

Tools may hide panels when not needed, but the layout contract must remain consistent.

### 3. Workspace vs Standalone Button Contract

#### Standalone Tool Mode

Allowed common buttons:

- Load
- Save local/export
- Reset
- Help/diagnostics
- Tool-specific actions

Not allowed as active workspace actions:

- Save Workspace
- Publish to Workspace
- Return to Workspace
- Open Workspace

If shown, workspace-only actions must be disabled with a clear explanation.

#### Workspace Mode

Allowed common buttons:

- Back to Workspace
- Save Workspace
- Publish/Apply to Workspace
- Export
- Reset
- Tool-specific actions

Workspace buttons must not appear active in standalone mode.

### 4. Multi-Event Editing Contract

Tools that edit multiple events, records, objects, frames, tiles, vectors, or timeline entries must wire the existing shared edit-history class.

Required actions:

- Cut
- Copy
- Paste
- Undo
- Redo

Required behavior:

- Actions must be enabled only when valid.
- Undo/redo state must update after edits.
- Cut/copy/paste must operate on the current selection.
- Clipboard behavior must be tool-safe and not corrupt unrelated state.
- Workspace mode edits must integrate with workspace dirty-state tracking.
- Standalone mode edits must integrate with tool-local dirty-state tracking.

Tools expected to comply include, at minimum:

- Sprite Editor
- Tilemap Studio
- Vector Asset Studio
- Vector Map Editor
- Replay/Event tools
- Any animation/timeline/frame editor
- Any asset list editor where multiple assets/items can be selected or edited

### 5. Selection and Control Readiness Contract

Every tool with selectable data must:

- Auto-select the first valid item after load.
- Visually indicate the selected item.
- Bind controls to selected data.
- Enable valid controls after required data is loaded.
- Keep disabled controls explainable.

Failures to prevent:

- Palette visible but disabled with valid data.
- Paint/stroke controls grayed out with valid palette.
- Objects list populated but nothing selected.
- Canvas blank until manual selection.
- Sample preview and tool preview rendering different images.

### 6. Empty State Contract

Empty states are valid only when clear.

Examples:

- `No approved assets found. Source checked: <path>.`
- `No vector objects available.`
- `No map loaded.`
- `No palette loaded.`

A blank panel is not an empty state.

## Codex Responsibilities

Codex must:

1. Update docs to reflect this corrected contract.
2. Report any tools that violate the corrected contract.
3. Do not implement broad fixes in this PR unless already scoped in the current lane.
4. Preserve roadmap text except status-only marker updates when execution-backed.
5. Place findings in `docs/dev/reports/PR_10_6_tool_system_contract_report.md`.

## Acceptance

- Contract clearly states samples use standalone tools.
- Contract clearly states games use workspace launch.
- Workspace-only buttons are not treated as sample requirements.
- Multi-event tools require cut/copy/paste/undo/redo using the existing shared class.
- Codex reports tool gaps against this contract.
