# Codex Commands - PR 10.6 Tool System Contract

Model: GPT-5.4
Reasoning: high

## Command

Review and update the project docs for the corrected tool-system contract.

Hard requirements:

1. Samples launch standalone tools only.
2. Games launch through games/index.html with Open in Workspace.
3. Workspace-specific buttons are game/workspace mode only.
4. Standalone tools show standalone-safe actions only.
5. Tools that edit multiple events/records/objects/frames/tiles/vectors/timeline entries must wire the existing shared edit-history class for:
   - cut
   - copy
   - paste
   - undo
   - redo
6. Produce a report at:
   docs/dev/reports/PR_10_6_tool_system_contract_report.md

Do not perform broad implementation rewrites in this PR. This is a contract/DoD update and gap-identification pass.

Return a ZIP at:
<project>/tmp/PR_10_6_<timestamp>.zip
